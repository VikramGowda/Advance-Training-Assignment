package com.bookstore.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import com.bookstore.dao.*;
import com.bookstore.entity.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;

import com.bookstore.db.*;


/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(jakarta.servlet.http.HttpServletRequest request, jakarta.servlet.http.HttpServletResponse response) throws IOException,ServletException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(jakarta.servlet.http.HttpServletRequest request, jakarta.servlet.http.HttpServletResponse response) throws IOException,ServletException {
		//Login fetch record username and password from request
		PrintWriter out=response.getWriter();
		String useruname=request.getParameter("uname");
		String userpassword=request.getParameter("pass");
		
		UserDao dao= new UserDao(jdbcconnection.getConnection());
		
		User u=dao.getUserByUnameAndPassword(useruname, userpassword);
		
		if(u==null) {
			
			out.println("Invalid Details!!.. Try again");
			
			jakarta.servlet.http.HttpSession s=request.getSession();
			
			response.sendRedirect("Login.jsp");
			
			
		}
		else {
			// login success
			
			jakarta.servlet.http.HttpSession s=request.getSession();
			s.setAttribute("currentUser", u);
			response.sendRedirect("Welcome.jsp");
			
		}
		
		
		
		
	}


}
